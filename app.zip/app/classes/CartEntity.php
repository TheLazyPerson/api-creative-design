<?php 

/**
* 
*/
class CartEntity
{	
	protected $product;
	protected $quantity;
	function __construct()
	{
		
	}

	function getProducts
}